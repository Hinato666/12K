/* @desc： 
* @author：yangliguo 
* @time：${DATE}
*/
<template>
  <div id="${COMPONENT_NAME}"></div>
</template>
<script>
export default {
  name: '${COMPONENT_NAME}',
  props: {},
  components: {},
  data () {
    return {}
  },
  filters: {},
  computed: {},
  created () {
    //初始化静态数据
    this.initStaticData()
  },
  mounted () {},
  beforeDestory () {},
  methods: {
    //初始化静态数据
    initStaticData(){
    }
  }
}
</script>

<style scoped lang="scss">
  #${COMPONENT_NAME}{
  }
</style>
